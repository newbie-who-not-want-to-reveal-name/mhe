document.addEventListener("DOMContentLoaded", function () {
    let username = localStorage.getItem("username");

    if (!username) {
        alert("Please log in first!");
        window.location.href = "index.html";
    } else {
        document.getElementById("username").innerText = username;
    }

    document.getElementById("logoutBtn").addEventListener("click", function () {
        localStorage.removeItem("username");
        alert("Logged out successfully!");
        window.location.href = "index.html";
    });
});